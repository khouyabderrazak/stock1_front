import { TestBed } from '@angular/core/testing';

import { ManufacutrerService } from './manufacutrer.service';

describe('ManufacutrerService', () => {
  let service: ManufacutrerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ManufacutrerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
