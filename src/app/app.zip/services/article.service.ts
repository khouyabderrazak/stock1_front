import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ArticleModule } from '../models/article/article.module';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ArticleService {
  private httpHeaders = new HttpHeaders({
    'Content-Type': 'multipart/form-data'
  });

  constructor() {}

  addArticle(http:HttpClient, article: ArticleModule, file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file, file.name);
    formData.append('article', JSON.stringify(article));
    
    return http.post("https://localhost:7020/api/Articles", formData);
  }
}
