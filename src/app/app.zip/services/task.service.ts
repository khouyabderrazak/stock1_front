import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Task } from '../models/Task';

@Injectable({
  providedIn: 'root'
})

export class TaskService {
  
  constructor() { 
         
  }

  public getALLTasks(http:HttpClient):Observable<any>{
     return http.get<Task[]>("https://localhost:7020/api/Task");
  }
}
