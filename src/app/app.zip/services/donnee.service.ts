import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DonneeService {

  constructor() {

  }

  poindsMessures: {
    id: number,
    label: string
  }[] = [
      {
        id: 1,
        label: 'lb'
      },
      {
        id: 1,
        label: 'kg'
      },
      {
        id: 1,
        label: 'g'
      }, {
        id: 1,
        label: 'oz'
      }
    ]
  messures: { id: number, label: string }[] = [
    {
      id: 1,
      label: 'cm'
    }, {
      id: 2,
      label: 'in'
    }
  ]
  revenus: { id: number, label: string }[] = [
    {
      id: 1,
      label: "Autres Charges"
    },
    {
      id: 2,
      label: "Frais d'expéditions"
    },
    {
      id: 3,
      label: "Remise"
    },
    {
      id: 4,
      label: "Revenus des frais de retard"
    },
    {
      id: 5,
      label: "Revenus d'intérêts"
    },
    {
      id: 6,
      label: "Revenus généraux"
    },
    {
      id: 7,
      label: "Ventes"
    }
]

  achatComptes = [
      {
  
        label: "Dépenses",
        items: [
          {value: 1,label: "Affranchissements" },
          {value: 2, label: "Amortissements" },
          {value: 3, label: "Autres frais" },
          {value: 4, label: "Créances irrécouvrables" },
          {value: 5, label: "Dépenses automobile" },
          {value: 6, label: "Dépenses de consultants" },
          {value: 7, label: "Dépenses de conciergerie" },
          {value: 8, label: "Dépenses d'informatique et d'internet" },
          {value: 9, label: "Dépenses téléphoniques" },
          {value: 10, label: "Fournitures de bureau" },
          {value: 11, label: "Frais bancaires et charges" },
          {value: 12, label: "Frais de cartes de crédit" },
          {value: 13, label: "Frais de déplacement" },
          {value: 14, label: "Frais de location" },
          {value: 15, label: "Frais d'hébergement" },
          {value: 16, label: "Imprimerie et papeterie" },
          {value: 17, label: "Non classé" },
          {value: 18, label: "Publicité et marketing" },
          {value: 19, label: "Remises d'achats" },
          {value: 20, label: "Réparations et entretien" },
          {value: 21, label: "Repas et divertissements" },
          {value: 22, label: "Salaires et rémunérations des employés" }
        ]
      },
      {
       
        label: "Coûts des marchandises vendues",
        items: [
          { value: 23, label: "Coûts des marchandises vendues" }
        ]
      }
    ]

    suiviLeStockComptes=[
      {
        label: 'Stock',
        items: [
          {
            value: 1,
            label: 'Équipement en stock'
          }
        ]
      }
      
    ]

}


