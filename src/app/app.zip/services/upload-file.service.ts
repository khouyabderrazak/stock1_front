import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UploadFileService {

  constructor() { 

  }
  uploadFile(http:HttpClient,file):Observable<any>{
       const formData=new FormData();
       formData.append('file',file,file.name);
       return http.post("https://localhost:7020/api/UploadFiles",formData,{reportProgress:true,observe:'events'});            
  }

}
