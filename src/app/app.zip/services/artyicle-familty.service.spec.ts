import { TestBed } from '@angular/core/testing';

import { ArtyicleFamiltyService } from './artyicle-familty.service';

describe('ArtyicleFamiltyService', () => {
  let service: ArtyicleFamiltyService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ArtyicleFamiltyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
