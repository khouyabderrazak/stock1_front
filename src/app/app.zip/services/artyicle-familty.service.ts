import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ArticleFamilyModule } from '../models/article-family/article-family.module';

@Injectable({
  providedIn: 'root'
})
export class ArtyicleFamiltyService {

  constructor() { 

  }

  getAllarticlesFamily(http:HttpClient):Observable<any>{
       return http.get<ArticleFamilyModule[]>("https://localhost:7020/api/ArticleFamily")
  }

}
