import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class PersonToContactModule {
  
  id:number 
  title:string 
  firstName :string
  lastName:string 
  email:string 
  phoneNumberPro:string 
  phoneNumberPortable :string
  department:string
  designation:string
  
 }
