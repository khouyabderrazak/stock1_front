import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssociatedDocsModule } from '../associated-docs/associated-docs.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class AssociatedDocsFilesModule {
  id:number
  filePath:string 
  associatedDocs?:AssociatedDocsModule
 }
