import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssociatedDocsFilesModule } from '../associated-docs-files/associated-docs-files.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class AssociatedDocsModule {
   id:number
   associatedDocsFile:AssociatedDocsFilesModule[]
 }
