import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddressModule } from '../address/address.module';
import { CurrencyModule } from '../currency/currency.module';
import { Task } from '../Task';
import { PaymentConditionModule } from '../payment-condition/payment-condition.module';
import { PersonContactsSupplierModule } from '../person-contacts-supplier/person-contacts-supplier.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class SupplierModule {

    supplierContacts?:PersonContactsSupplierModule[]
    id: number
    title: number
    firstName: string
    lastName: string
    companyName: string
    type: number
    displayName: string
    email?: string
    phonePro: string
    phonePortable: string
    note?: string
    billingAddress?: AddressModule
    deliveryAddress?: AddressModule
    currency?: CurrencyModule
    tax?: Task
    paymentCondition?: PaymentConditionModule
    associatedDocs?: string
 }
