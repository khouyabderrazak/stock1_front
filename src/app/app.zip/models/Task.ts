export class Task{
        id: number;
        title: string;
        ratio: number
}