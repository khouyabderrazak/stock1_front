import { Article } from "./Article";
import { Task } from "./Task";

export class ArticleTap{
    id:number;
    article: Article;
    quantite: number;
    taskId: number
}