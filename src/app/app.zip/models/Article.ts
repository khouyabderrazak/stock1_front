export class Article{
    id: number;
    name: string;
    prix: number;
}

  
 